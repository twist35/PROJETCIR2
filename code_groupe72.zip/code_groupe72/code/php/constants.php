<?php
/*
  Créé par Antonin SABIRON et Lucas Le Bihan
    le 15/06/2022
    Pour le projet de fin d'année CIR2
    contient les constantes du projet
*/
// Database constants.
  define('DB_USER', 'user1');
  define('DB_PASSWORD', 'isen29'); // mot de passe à changer pour plus de sécurité
  define('DB_NAME', 'projetcir2');
  define('DB_SERVER', 'localhost'); 
?>